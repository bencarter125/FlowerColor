This readme file was generated on 23 Jan 2024 by Ben Carter


GENERAL INFORMATION

Title of Dataset: Scripts and Sample files for ColorSelector v1.0

Author/Principal Investigator Information
Name: Ben Carter
Institution: San Jose State University
Email: benjamin.carter@sjsu.edu

Data description 
This includes Rshiny apps and R scripts used by Luong et al. Original data were downloaded from iNaturalist and from GBIF between 1 Jan 2022 and 10 July 2022.



DATA & FILE OVERVIEW

File List: 
\ColorSelectorLocal		a folder with an Rshiny app and associated helper scripts and sample data
	app.R				an Rshiny app to be opened in Rstudio
	\functions			a folder with three Rscripts that are called by ‘app.R’
	\images 			a folder containing three folders of sample images for Processing
\ColorSelectorNet		a folder with an Rshiny app and associated helper 
							scripts and sample data
	app.R				an Rshiny app to be opened in Rstudio
	\functions			a folder with three Rscripts that are called by ‘app.R’
	SampleInputFile.csv	a text file with sample input for ‘app.R’
\ImageSelector 			a folder with an Rshiny app and associated helper scripts and sample data
	app.R				an Rshiny app to be opened in Rstudio
	SampleInput.csv 	a text file with sample input for ‘app.R’
\R scripts				a folder with two R scripts and 8 sample data files. 
							Users should open ‘R Scripts.R’ in R. Functions called in that 
							script are stored in ‘Script_Functions.R’ which should only be 
							opened for troubleshooting purposes. The eight sample files 
							provide examples of the functions that can be executed within 
							‘R Scripts.R’. 
INSTRUCTION MANUALv1.pdf a detailed instruction manual for running the above 
		scripts and Rshiny apps.





