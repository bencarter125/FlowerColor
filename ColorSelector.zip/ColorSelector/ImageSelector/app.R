#
# Image Selector

# follow the steps below to run the app. See the manual for detailed instructions

# 1) load the input data. 
# This is an output file from MakeInput Script with data 
# downloaded from GBIF. If you downloaded data from 
# iNaturalist directly, there's no need to run this ImageSelector app.
# change your filename here:
metadata <- read.csv("SampleInput.csv")


# 2) Note: There will be two output files:
#  Singletons.csv: these are the records which only had one image
#  outfile.csv: these are the results of running the app and include only one
#      image per iNaturalist record
#  Prior to  moving on to ColorSelector, you will want to paste these two files together. 
#      This can easily be done using excel or a text editor.

# 3) Column names are provided for Singletons.csv but not for outfile.csv, even though the columns match.

###################### end of instructions ###########################3

library(shiny)
library(raster)
library(gdistance)



#separating duplicates from singleton unique gbifIDs
#generating duplicates that will be selected as best image
dup <- duplicated(metadata$iNatID)
tokeep <- unique(metadata$iNatID[dup==TRUE])
#save singletons to a separate outfile
singletons <- metadata[metadata$iNatID%in%tokeep==FALSE,]
write.csv(singletons,"Singletons.csv",row.names=FALSE)
#duplicates without singletons
metadata <- metadata[metadata$iNatID%in%tokeep,]


#create a vector with the number of images per gbifID. 
# the occurrence number is equivalent to the gbifID/iNatID but is easier to remember
occurrence <- vector(length=dim(metadata)[1])
u <- unique(metadata$iNatID)

for (i in 1:length(u)) {
    
    w <- which(metadata$iNatID == u[i])
    occurrence[w] <- i
}

metadata$occurrence <- occurrence

# add a notes column for user input
notescolumn <- vector(length=dim(metadata)[1])          
metadata$notes <- notescolumn                          


# Define UI for application
ui <- fluidPage(

    # Application title
    titlePanel("Image Selector"),

    # Sidebar with a slider input for number of bins 
    sidebarLayout(
        sidebarPanel(
            
            helpText("Enter Start Number, hit Refresh to begin. Keep track of the current ID at the end of each session."),
            br(),
            
            numericInput(inputId = "start", label = "Start Number", value = "Enter text..."),
            
            br(),
            actionButton(inputId = "refresh", label = "Refresh"),
            
            br(),
            br(),
            
            helpText("Select the best image and press 'Next Set'"),
            
            radioButtons("buttons", "Select best image:",
                         choices = c("None", "Image 1", "Image 2", "Image 3",
                                       "Image 4"),
                         selected = "None"),
            br(),
            
            actionButton(inputId = "nextset", label = "Next Set"),
            
            helpText("Hit 'Next Set' to continue to the next ID number"),

            br(),
            
            textInput(inputId = "notes", label = "Notes for outliers/special ones. Do not use commas."),    #  NEW 
        ),

        
        mainPanel(
             
        tags$head(tags$style(HTML("
        @import url('https://fonts.googleapis.com/css2?family=Berkshire+Swash&family=Bungee+Shade&family=Cinzel+Decorative:wght@400;700&family=Comforter&family=DotGothic16&family=Fleur+De+Leah&family=Press+Start+2P&display=swap');
        
        h2{
         font-family: 'Fleur De Leah', cursive; 
         font-size: 50px;
         color: green
        } 
        
        .shiny-input-container {
            color: #474747;
        }"
                                  )
                             ) 
                  ),
        
        textOutput("IDtracker"),
        
        tags$head(tags$style(HTML("
        @import url('https://fonts.googleapis.com/css2?family=Berkshire+Swash&family=Bungee+Shade&family=Cinzel+Decorative:wght@400;700&family=Comforter&family=DotGothic16&family=Fleur+De+Leah&family=Libre+Barcode+39+Text&family=Press+Start+2P&display=swap');
        
        #IDtracker{
         font-family: 'Press Start 2P', cursive; 
         font-size: 20px;
         color: green;
        } 
        
        .shiny-input-container {
            color: #474747;
        }"
        
        # OR 
        
        #"#IDtracker{font-size: 25px; font-family: Helvetica, sans-serif; background-color: 
        #rgba(255,255,255,0.40); color: green; border-style: none;}"),
                                  
                                 )
                             )
                  ),
        
        br(),
        
        span(textOutput("warningmessage"), style="color:red"),
        
        tags$head(tags$style("#warningmessage{font-size: 20px; font-family: Times; font-weight: bold; background-color: rgba(255,255,255,0.40); color: red; border-style: solid;}")),
        
        plotOutput(outputId = "gbifImagesPlot"),
           
        imageOutput(strong("gbifImages")),
        
        br(),
           
        )
    )
)

server <- function(input, output,session) {

    # this keeps track of which iNat occurrence you're on
    IDcounter = reactiveValues(i=0)
    # this keeps track of how many times the 'next set' button has been clicked
    NextSetCounter = reactiveValues(n=0)
    
    
    # this controls the Next Set button. When next set is clicked-
    #  if the 'none' radio button is currently selected, record 'nodata', otherwise record the original data line
    #  corresponding to the image selected
    observeEvent(input$nextset, {
        if(input$buttons!="None")
        {
            mini<- metadata[metadata$occurrence==IDcounter$i,]
            choices<- c("Image 1", "Image 2", "Image 3", "Image 4")
            ww<- which(choices==input$buttons)
            if(ww <= length(which(metadata$occurrence==IDcounter$i)))
            {
                mini$notes[ww] <- input$notes                                     
                cat(paste(paste(mini[ww,], collapse=","), "\n", sep=""),
                    file="outfile.csv",append=TRUE)}
        }
        
        else
        { 
            none<- metadata[metadata$occurrence==IDcounter$i,]
            none[1,-1]<- "nodata"
            cat(paste(paste(none[1,],collapse=","),"\n",sep=""),
                file="outfile.csv",append=TRUE)}
        
    })
    
    # when the next set button is clicked, 
    #   advance 'NextSetCounter' by one
    #   advance 'IDcounter' to equal 'start' + 'NextSetCounter'
    # when refresh button is clicked, reset 'IDcounter' to the number in the text box and
    #   reset 'NextSetCounter' to zero
    observeEvent(input$nextset, {NextSetCounter$n <- NextSetCounter$n+1})
    observeEvent(input$nextset, {IDcounter$i <- input$start + NextSetCounter$n})
    observeEvent(input$refresh, {IDcounter$i <- input$start
                                 NextSetCounter$n <- 0})
    observeEvent(input$nextset, {
        choices<- c("None","Image 1", "Image 2", "Image 3", "Image 4")
        ww<- which(choices==input$buttons)
        if(ww-1 > length(which(metadata$occurrence==IDcounter$i))){
        output$warningmessage<- renderText({paste("Error: For the previous ID, you chose an image that does not exist!
            Enter", IDcounter$i-1, "in the 'Start Number' box, select 'None' for image number, and hit refresh to redo the image selection.",
                                                  sep = " ")})  
        }
        
        else {
        output$warningmessage<- renderText({"Nice job! :)"})
        
        }
    observeEvent(input$nextset, {
            updateRadioButtons(session, "buttons", selected = "None")
        })
    })
    
    
    output$IDtracker <- renderText({
        paste("Current ID = ", IDcounter$i)
    })
    
    
    IDs<-unique(metadata$iNatID)
    
    images.to.pick<-vector(length=length(IDs))
    
    
output$gbifImagesPlot <- renderPlot({

    
    images<-which(metadata$occurrence==IDcounter$i)
    
    if (length(images) >= 1)
    {
        
    num.images<-length(images)

    
    par(mfrow=c(2,2)) #or 3,3 for 6 images
    for (i in 1:num.images)
    {
        if(num.images > 4) #change to 6?
        {images<-images[1:4]}

        download.file(metadata$imageURL[images[i]],"image.jpg", mode='wb')
        im<-brick("image.jpg")
        plotRGB(im,r=1,g=2,b=3)
        legend("bottom",legend=paste("Image",i),cex=2)
    } #close the for loop
} #end if statement
    
    else {
    plot(0,0, main = "Enter Number Into the Start Number Box", col = 0, axes = F, xlab = "", ylab = "")
    }#end else statement
    
})


 
}

    
# Run the application 
shinyApp(ui = ui, server = server)
