#
# ColorExtractor

# Here are the steps to run this app. See the manual for detailed instructions:
# 1) load csv with image urls 
# this file must be in the same folder as this app.R file that you have open
# change the filename here to match your input filename
image.data<-read.csv("SampleInputFile.csv")


# 2) If RUNNING ON A PC, see note at line 138- you'll need to make a simple change to the code
# If running on a mac, no need to change anything

# 3) Note: the outfile will not have column names. These are the column names of outfile:
#species,gbifID,iNatID,imageNumb,lat,long,year,mon,day,clickX,clickY,timeStamp,R,G,B

# 4) Start the app by clicking the 'Run App' icon with the green arrow directly above this window. The new interface will pop up.

# 5) Once the app opens, go to the 'Species' drop down menu to load a species. Once the image loads, you can begin collecting data



######## end of instructions ########################

# load necessary packages
library(shiny)
library(raster)
library(rgdal)


# load some functions
source("functions/extractColor.R")
source("functions/getNext.R")

# remove any empty rows if present
w<-which(image.data$imageURL=="")
if(length(w)!=0) {image.data<-image.data[-w,]}


# Define UI for application 
# User interface ----
ui <- fluidPage(
    titlePanel("Flower Color Selection"),
    
    sidebarLayout(
        sidebarPanel(
            #selectInput("imageFile","Select input file",
            #            choices=list.files(paste(getwd(),"/imageFiles",sep=""))),
            helpText("To begin, select 'capitatum' from the menu below"),
            # new bit
            #selectInput("imageFolder","Select Image Folder",
             #           choices=list.files(paste(getwd(),"/Images",sep=""))),
            
            selectInput("species", 
                        label = "Species:",
                        choices = c("None",sort(unique(image.data$species))),   # CHANGEd
                        selected = "None"),
            helpText("To start from any image, enter an image number, then 'Refresh' then 'Next'. So to view image 11, enter 10, then 'Refresh' then 'Next'. "),
            numericInput("numSelect","Enter Starting Image Number",1),
            helpText("Click button below once after entering a new starting number"),
            actionButton("counterReset",
                         label="Refresh Starting Number"),
            helpText("Click below to view the next image"),
            actionButton("nextImage",label="Next Image"),
            textOutput("imageInfo")
        ),
        
        mainPanel(
            # first image (for sizing)
            plotOutput("mainPlot",
                       brush = brushOpts(id="plot2_brush",resetOnNew=TRUE)),
            # second image (for clicking)
            imageOutput("plot2",
                        click="image_click"),
            verbatimTextOutput("kcount"),
            verbatimTextOutput("clickCount"),
              #line below works but is not needed
            #verbatimTextOutput("clickInfo2"),
            plotOutput("colorPoints")

            
            
            )
    )
)

# Define server logic required to draw a histogram
server <- function(input, output) {
    
    #image.data<-reactive({read.csv(paste(getwd(),"/imageFiles/",input$imageFile,sep=""))})
    jcounter<-reactiveValues(j=0)
    clickCounter<-reactiveValues(k=0)
    kcounter<-reactiveValues(k=1)
    
    observeEvent(input$nextImage,{jcounter$j<-jcounter$j+1})
    observeEvent(input$counterReset,{jcounter$j<-0})
    observeEvent(input$nextImage,{
        kcounter$k<-(jcounter$j +  input$numSelect)
        })
    
    observeEvent(input$image_click,{
        clickCounter$k<-clickCounter$k+1
        })
    output$imageTracker<-renderText({
        paste("current image (k)= ",kcounter$k)
        })
    output$startImage<-renderText({
        paste("starting image= ",input$numSelect)
    })
    output$currentK<-renderText({
        paste("j= ",jcounter$j)
    })
    
    output$currentFile<-renderPrint({
        print(paste("Current species:",image.data$species[1]))       # CHANGEd
    })
    
    observeEvent(input$nextImage,{
        clickCounter$k<-0
    })
    output$clickCount<-renderText({
        print(paste("Number of clicks on this image:",clickCounter$k))
    })
    
    output$kcount<-renderText({
        nImgs<-length(which(image.data$species==input$species))  # CHANGEd
        print(paste("This is image number",kcounter$k,"out of",
                    nImgs,"for this species"))
    })
    
    output$mainPlot <- renderPlot({
        # generate bins based on input$bins from ui.R
        if(kcounter$k==0) {
            plot(0,0,col=0)
            text(0,0,"Click Next Image to load image")
        } else {
            spMatrix<-image.data[image.data$species==input$species,]    # CHANGEd

################### Change here between Mac and PC #################
# have only one of these two lines active. The one you don't want should be 
# commented out by placing a '#' in front of the line of code

    # mac version:            
            download.file(spMatrix$imageURL[kcounter$k],"image.jpg")
    # pc version:
            #download.file(spMatrix$imageURL[kcounter$k],"image.jpg",mode='wb')
################# end Mac vs PC version section ###################
            
            
            im<-brick("image.jpg")
            plotRGB(im,r=1,g=2,b=3)
            }
    })
    
    # ------------------------- plot zooming stuff ---------------
    ranges2 <- reactiveValues(x = NULL, y = NULL)
    
    output$plot2 <- renderPlot({
        if(kcounter$k==0) {
            plot(0,0,col=0)
            text(0,0,"Click Next Image to load image")
        } else {
            spMatrix<-image.data[image.data$species==input$species,]  #### CHANGEd
            im<-brick("image.jpg")
            plotRGB(im,r=1,g=2,b=3,
                    ext=c(ranges2$x,ranges2$y))
        }
    })
    
    observe({
        brush <- input$plot2_brush
        if (!is.null(brush)) {
            ranges2$x <- c(brush$xmin, brush$xmax)
            ranges2$y <- c(brush$ymin, brush$ymax)
            
        } else {
            ranges2$x <- NULL
            ranges2$y <- NULL
        }
    })
    # ------------------------ end plot zooming stuff ------------
    
    output$colorPoints<-renderPlot({
        plot(0,0,col=0)
        if(clickCounter$k!=0){
            im<-brick("image.jpg")
            ext<-extract(im,data.frame(matrix(c(input$image_click$x,input$image_click$y),nrow=1)))
            #for.rgb<-c(ext[1,1]/255,ext[1,2]/255,ext[1,3]/255,1)
            points(0,0,pch=19,col=rgb(ext[1,1]/255,ext[1,2]/255,ext[1,3]/255,1),cex=5)
        }
    })
#    output$colorPoints<-renderPlot({
#        plot(c(1,15),c(0,2),col=0)
#        if(clickCounter$k!=0)
#        {
#            im<-brick("image.jpg")
#            ext<-extract(im,data.frame(matrix(c(input$image_click$x,input$image_click$y),nrow=1)))
#            for.rgb<-c(ext[1,1]/255,ext[1,2]/255,ext[1,3]/255,1)
#            points(clickCounter$k,1,
#                   col=1,
#                    pch=19,cex=1.5)
#        }
#        
#    })
    
    output$clickInfo2<-renderPrint({
        if(length(input$image_click$x)!=1) {
            print("Click to get RGB values")
        } else {
        im<-brick("image.jpg")
        ext<-extract(im,data.frame(matrix(c(input$image_click$x,input$image_click$y),nrow=1)))
        colnames(ext)<-c("R","G","B")
        print(ext)
        }
    })
    
    
    output$imageInfo<-renderPrint({
        nImgs<-length(which(image.data$species==input$species))      # CHANGEd
        print(paste("Number of images for this species:",nImgs))
    })
    
   
    observeEvent(input$image_click,{
        spMatrix<-image.data[image.data$species==input$species,]  # CHANGEd
        timest<-as.character(Sys.time())
        im<-brick("image.jpg")
        ext<-extract(im,data.frame(matrix(c(input$image_click$x,input$image_click$y),nrow=1)))
        ext<-as.vector(ext[1,])
        output<-c(spMatrix$genus[kcounter$k],
                      spMatrix$species[kcounter$k],
                      spMatrix$gbifID[kcounter$k],
                      spMatrix$iNatID[kcounter$k],
                      kcounter$k,
                      spMatrix$lat[kcounter$k],
                      spMatrix$long[kcounter$k],
                      spMatrix$year[kcounter$k],
                      spMatrix$month[kcounter$k],
                      spMatrix$day[kcounter$k],
                      input$image_click$x,
                      input$image_click$y,
                      timest,
                     ext)
        #sheet_append(my.ss,output,sheet=2)
        
        cat(paste(paste(output,collapse=","),"\n",sep=""),
            file="outfile.csv",append=TRUE)
        
    })
 
}



# Run the application 
shinyApp(ui = ui, server = server)
