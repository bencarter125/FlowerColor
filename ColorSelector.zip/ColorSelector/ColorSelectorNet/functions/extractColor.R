
extractColor<-function(spMatrix,spName,dataEntryby,max.images,Nclicks)
{

# reduce max.images if necessary
if(dim(spMatrix)[1] < max.images) {max.images<-dim(spMatrix)[1]}

# set up output data frame
anchorPts<-data.frame(matrix(nrow=0,ncol=26))
colnames(anchorPts)<-c("species","Rmin","R1Q", "Rmed","Rmean","R3Q","Rmax","Gmin","G1Q","Gmed","Gmean","G3Q","Gmax",
"Bmin","B1Q","Bmed","Bmean","B3Q","Bmax","gbifID","image",
"dataInput","timeStamp","long","lat","collectionDay")

######### Collect data for a species
# loop through the images for the species
for(i in 1:max.images)   #i loop through images for a species
{
	# build export matrix

	download.file(spMatrix$identifier[i],"image.jpg")
	im<-brick("image.jpg")
	plotRGB(im,r=1,g=2,b=3)
	lg<-paste(spName,i,"of",max.images)
	legend("topright",legend=lg,cex=.5,col=0,pch=19,bg="gray90")
	# add to output matrix
	anchorPts[i,"species"]<-paste(		
		image.data$genus[i],spMatrix$specificEpithet[i])
	anchorPts[i,"gbifID"]<-spMatrix$gbifID[i]
	anchorPts[i,"dataInput"]<-dataEntryBy
	anchorPts[i,"long"]<-spMatrix$decimalLongitude[i]
	anchorPts[i,"lat"]<-spMatrix$decimalLatitude[i]
	anchorPts[i,"collectionDay"]<-spMatrix$verbatimEventDate[i]
	anchorPts[i,"timeStamp"]<-as.character(Sys.time())
	anchorPts[i,"image"]<-unlist(
		strsplit(spMatrix$identifier[i],split="\\?"))[2]
	# ask whether image should be skipped
	response<-readline(prompt="Skip image? (y/n):  ")
	if(response=="y") {
		anchorPts[i,2:19]<-rep("NA",18)
		next
		} else{
		cl<-click(im,n=Nclicks,id=TRUE,xy=TRUE,cell=TRUE,type="n")
		#return(cl)
		anchorPts[i,2:19]<-c(summary(cl[,3]), summary(cl[,4]),
					summary(cl[,5]))	
		}
} # end loop through images
return(anchorPts)
}
