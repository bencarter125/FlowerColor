
# get.next takes input specific epithets from the input (url) file
# and a url for the google sheet with a 'species' binomial column
# returns the alphabetically next species that needs to be completed

get.next<-function(inputNames,url){
	
the.spp<-sort(unique(inputNames))
completed_spp<-unique(read_sheet(url)$species)
completed.ep<-unlist(lapply(completed_spp,function(x) unlist(strsplit(x,split=" "))[2]))
next.sp<-the.spp[!the.spp%in%completed.ep]
if(length(next.sp)==0) {print("Done with this genus! Go to new genusFolder")
	} else {next.sp[next.sp!=""][1]}
}
