# file prep

#this takes as input a GBIF download folder
# returns a dataframe combining multimedia and occurrence data

# imageData<-function(x)
		# x is the folder name of a GBIF folder
imageData<-function(x){

mm<-read.csv(paste(x,"/","multimedia.txt",sep=""),sep="\t")
occ<-read.csv(paste(x,"/","occurrence.txt",sep=""),sep="\t")
occ<-occ[,c("gbifID","genus","specificEpithet",
	"decimalLatitude","decimalLongitude",
	"verbatimEventDate","stateProvince",
	"year","month","day")]
occ<-occ[occ$gbifID%in%mm$gbifID,]
occ<-occ[order(occ$gbifID),]
mm<-mm[mm$gbifID%in%occ$gbifID,]
mm<-mm[order(mm$gbifID),]
	if(length(unique(mm$gbifID))==length(unique(occ$gbifID)))
	{print("occ & mm alignment OK")} else {
		print("occ & mm alignment FAIL")}
new.occ<-data.frame(matrix(ncol=dim(occ)[2],nrow=0))
colnames(new.occ)<-colnames(occ)
for(i in 1:dim(mm)[1]){
	new.occ[i,]<-occ[which(occ$gbifID==mm$gbifID[i]),]
	}
new.occ<-cbind(new.occ,mm[,c("identifier","creator")])
write.csv(new.occ,"appInput.csv",row.names=F)
}
	
