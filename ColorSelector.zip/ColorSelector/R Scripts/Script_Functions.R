
# This file is source code for several of the functions used in the 'R scripts.R' file. General users should be using 'R scripts.R'. You should only be modifying code in this file if you know what you're doing and are modifying the functions of the commands using in 'R scripts.R'

##################################################
########## makeInput_GBIF ####################
##################################################
# convert from GBIF to standard format
# usage:
#convertFromGBIF(file.choose(),type="pc","outfile.csv")
makeInput_gbif<-function(
	occurrence,multimedia,outfile) {
gbif.o<-read.csv(occurrence,sep="\t")
gbif.m<-read.csv(multimedia,sep="\t")

# extract columns of interest from dataset
iNatID<-gbif.o$catalogNumber
gbifID<-gbif.o$gbifID
long<-gbif.o$decimalLongitude
lat<-gbif.o$decimalLatitude
species<-gbif.o$species
scientificName<-gbif.o$scientificName
gbifTaxonID<-gbif.o$taxonID
year<-gbif.o$year
month<-gbif.o$month
day<-gbif.o$day
verbatimDate<-gbif.o$eventDate
iNatUser<-gbif.o$recordedBy
obscured<-rep("false",dim(gbif.o)[1])
qualityGrade<-rep("research",dim(gbif.o)[1])

fromGBIF<-data.frame(cbind(iNatID,gbifID,long,lat,
	species,scientificName,gbifTaxonID,verbatimDate,year,
	month,day,iNatUser,obscured,
	qualityGrade))
rm(gbif.o)

# build matrix for output. this disperses the information for each occurrence across all the images that have those occurrence data
out<-gbif.m[,c("gbifID","identifier")]
rm(gbif.m)
colnames(out)[2]<-"imageURL"
u<-unique(out$gbifID)
for(i in 1:length(u)){
	w1<-which(out$gbifID==u[i])
	w2<-which(fromGBIF$gbifID==u[i])
	out$iNatID[w1]<-fromGBIF$iNatID[w2]
	out$long[w1]<-fromGBIF$long[w2]
	out$lat[w1]<-fromGBIF$lat[w2]
	out$species[w1]<-fromGBIF$species[w2]
	out$scientificName[w1]<-
		fromGBIF$scientificName[w2]
	out$gbifTaxonID[w1]<-fromGBIF$gbifTaxonID[w2]
	out$verbatimDate[w1]<-fromGBIF$verbatimDate[w2]
	out$year[w1]<-fromGBIF$year[w2]
	out$month[w1]<-fromGBIF$month[w2]
	out$day[w1]<-fromGBIF$day[w2]
	out$iNatUser[w1]<-fromGBIF$iNatUser[w2]
	out$obscured[w1]<-fromGBIF$obscured[w2]
	out$qualityGrade[w1]<-fromGBIF$qualityGrade[w2]
	} # end for loop

# write the outfile
write.csv(out,outfile,row.names=FALSE)
print(paste("Process complete. look for",outfile,"in working directory"))
} # end function



##################################################
########## makeInput_inat ####################
##################################################
# convert from iNat to standard format
# usage:

makeInput_inat<-function(occurrence,outfile){

inat.f<-read.csv(occurrence)
# extract data from input file
gbifID<-rep(NA,dim(inat.f)[1])
imageURL<-inat.f$image_url
iNatID<-inat.f$id
long<-inat.f$long
lat<-inat.f$lat
species<-inat.f$scientific_name
scientificName<-rep(NA,dim(inat.f)[1])
gbifTaxonID<-inat.f$taxon_id
verbatimDate<-inat.f$observed_on
iNatUser<-inat.f$user_login
obscured<-inat.f$coordinates_obscured
qualityGrade<-inat.f$quality_grade

dt<-as.POSIXlt(verbatimDate,format="%Y-%m-%d")
year<-format(dt,format="%Y")
month<-format(dt,format="%m")
day<-format(dt,format="%d")

# build output file
out<-as.data.frame(cbind(gbifID, imageURL, iNatID, long, lat, species, scientificName, gbifTaxonID, verbatimDate, year, month, day, iNatUser, obscured, qualityGrade))

w<-which(out$imageURL=="")
if(length(w)!=0){out<-out[-w,]}
write.csv(out,outfile,row.names=FALSE)

print(paste("Process complete. look for",outfile,"in working directory"))
} # end makeInput_inat



##################################################
########## Duplicate Remover ####################
##################################################
# compare two files in standard format. From one of the files, remove all records that also occur in the other file. No pc vs mac versions. Must set wd prior to using

# usage:
# duplicateRemover("oldFile.csv", 
#	"newFile.csv",
#	"smallerNewFile.csv")

duplicateRemover<-function(file1,file2,outfile){
	f1<-read.csv(file1)
	f2<-read.csv(file2)
	# find duplicates, remove from f2
	toKeep<-which(f2$iNatID%in%f1$iNatID==FALSE)
	f3<- f2[toKeep,]
	# print stats
	print(paste("iNat occs kept:",
		length(unique(f3$iNatID))))
	print(paste("iNat occs dropped:",
		length(unique(f2$iNatID))- 
		length(unique(f3$iNatID))))
	write.csv(f3,outfile,row.names=F)
	}


##################################################
########## Download images ####################
##################################################
# take a file in standard format and  use it to download all images to the working directory

downloadImages<-function(infile,type){
	data<-read.csv(infile)
	urls<-data$imageURL
	iNatIDs<-data$iNatID
	# mac version
	if(type=="mac"){
	for(i in 1:length(urls)){
 		if (urls[i] == "") next
 		outfile<-paste("iNatID_",iNatIDs[i],
 			".jpg",sep="")
 		download.file(urls[i],outfile)
		}	# end loop
	} # end mac version
	
	# pc version
	if(type=="pc"){
	for(i in 1:length(urls)){
		if (urls[i] == "") next
		outfile<-paste("iNatID_",iNatIDs[i],
 			".jpg",sep="")
		download.file(urls[i], outfile, 
			internal="wininet", mode ="wb")
		} # end for loop
	} # end pc version
} # end function

##################################################
########## Reassociate metadata ####################
##################################################
# used when images were downloaded and data were collected with local version of color selector.
# this takes the origninal standard format file and the color selection data and inserts the metadata (location, date) into the color selection file
addMetadata<-function(colors,infile,outfileName){
		
	output.file<-read.csv(colors,header=F)
	input.file<-read.csv(infile)
	
	outputIDs1<-output.file[,1]
	splitter<-function(x){
		z<-unlist(strsplit(x,"/"))
		z<-z[length(z)]
		z<-gsub("iNatID_","",z)
		z<-gsub(".jpg","",z)
		return(as.numeric(z))
		}
	outputIDs<-unlist(lapply(outputIDs1,splitter))
	inputIDs<-input.file$iNatID
	u<-unique(outputIDs)
	for(i in 1:length(u)){
		w1<-which(inputIDs==u[i])[1]
		w2<-which(outputIDs==u[i])
		output.file[w2,9]<-input.file$year[w1]
		output.file[w2,10]<-input.file$month[w1]
		output.file[w2,11]<-input.file$day[w1]
		output.file[w2,12]<-input.file$long[w1]
		output.file[w2,13]<-input.file$lat[w1]
		}
	colnames(output.file)<-c("imgFileName","imgNum","timestamp","imgX","imgY","R","G","B","year","month","day","long","lat")
	write.csv(output.file,outfileName,row.names=F)	
}

##################################################
########## SummarizeColorSamples ####################
##################################################
# derive color summaries (e.g. mean, variance, number of samples) for each image
SummarizeColorSamples_local<-function(x,outname){
	splitter<-function(z){
		z1<-unlist(strsplit(u[1],"/"))
		z2<-z1[length(z1)]
		return(z2)
		}
	dt<-read.csv(x,header=F)
	colnames(dt)<-c("path","img","time","x","y","R","G","B")
	u<-unique(dt[,1])
	filenames<-unlist(lapply(u,splitter))
	out<-data.frame(matrix(nrow=length(filenames),ncol=20))
	colnames(out)<-c("img","Nsamples",
	"Rmean","Rmedian","Rmax","Rmin","Rvariance","Rstdev",
	"Gmean","Gmedian","Gmax","Gmin","Gvariance","Gstdev",
	"Bmean","Bmedian","Bmax","Bmin","Bvariance","Bstdev")
	for(i in 1:length(u)){
		mini<-dt[dt[,1]==u[i],]
		out$img[i]<-filenames[i]
		out$Nsamples[i]<-dim(mini)[1]
		
		out$Rmean[i]<-mean(mini$R)
		out$Rmedian[i]<-median(mini$R)
		out$Rmax[i]<-max(mini$R)
		out$Rmin[i]<-min(mini$R)
		out$Rvariance[i]<-round(var(mini$R),4)
		out$Rstdev[i]<-round(sd(mini$R),4)
		
		out$Gmean[i]<-mean(mini$G)
		out$Gmedian[i]<-median(mini$G)
		out$Gmax[i]<-max(mini$G)
		out$Gmin[i]<-min(mini$G)
		out$Gvariance[i]<-round(var(mini$G),4)
		out$Gstdev[i]<-round(sd(mini$G),4)
		
		out$Bmean[i]<-mean(mini$B)
		out$Bmedian[i]<-median(mini$B)
		out$Bmax[i]<-max(mini$B)
		out$Bmin[i]<-min(mini$B)
		out$Bvariance[i]<-round(var(mini$B),4)
		out$Bstdev[i]<-round(sd(mini$B),4)
	}
	write.csv(out,outname,row.names=FALSE)	
}


SummarizeColorSamples_net<-function(x,outname){
	dt<-read.csv(x,header=F)
	colnames(dt)<-c("species","gbifID","iNatID","img","lat","long","year","month","day","x","y","timestamp","R","G","B")
	u<-unique(dt$iNatID)
	filenames<-u
	out<-data.frame(matrix(nrow=length(filenames),ncol=26))
	colnames(out)<-c("iNatID","species","long","lat","year","month","day",
	"Nsamples",
	"Rmean","Rmedian","Rmax","Rmin","Rvariance","Rstdev",
	"Gmean","Gmedian","Gmax","Gmin","Gvariance","Gstdev",
	"Bmean","Bmedian","Bmax","Bmin","Bvariance","Bstdev")
	for(i in 1:length(u)){
		mini<-dt[dt$iNatID==u[i],]
		out$iNatID[i]<-filenames[i]
		out$species[i]<-mini$species[1]
		out$long[i]<-mini$long[1]
		out$lat[i]<-mini$lat[1]
		out$year[i]<-mini$year[1]
		out$month[i]<-mini$month[1]
		out$day[i]<-mini$day[1]
		out$Nsamples[i]<-dim(mini)[1]
		
		out$Rmean[i]<-mean(mini$R)
		out$Rmedian[i]<-median(mini$R)
		out$Rmax[i]<-max(mini$R)
		out$Rmin[i]<-min(mini$R)
		out$Rvariance[i]<-round(var(mini$R),4)
		out$Rstdev[i]<-round(sd(mini$R),4)
		
		out$Gmean[i]<-mean(mini$G)
		out$Gmedian[i]<-median(mini$G)
		out$Gmax[i]<-max(mini$G)
		out$Gmin[i]<-min(mini$G)
		out$Gvariance[i]<-round(var(mini$G),4)
		out$Gstdev[i]<-round(sd(mini$G),4)
		
		out$Bmean[i]<-mean(mini$B)
		out$Bmedian[i]<-median(mini$B)
		out$Bmax[i]<-max(mini$B)
		out$Bmin[i]<-min(mini$B)
		out$Bvariance[i]<-round(var(mini$B),4)
		out$Bstdev[i]<-round(sd(mini$B),4)
	}
	write.csv(out,outname,row.names=FALSE)	
}
