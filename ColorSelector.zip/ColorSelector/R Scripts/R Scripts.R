# This file includes the following functions:
# makeInput
# duplicateRemover
# download Images

# Before you begin- make sure that your working directory in R is set to the Scripts folder (the folder that holds this file). If you're not familiar with this, a quick internet search for 'change working directory in R' will provide everything you need.

#########################################################
################### makeInput ###########################
#########################################################
 
# There are two versions:
# makeInput_inat() converts one file downloaded from iNaturalist into a standardized format
# makeInput_gbif() converts two files downloaded from GBIF into a standardized format

# makeInput_inat
# 1. Find the file you downloaded from iNaturalist and place it into the working directory (the same folder that this file is in)
# 2. change the input filename below from "sampleData_1.csv" to your filename
# 3. Change the output file name from 'outfile.csv' to something more informative
# 4. Copy and paste the two lines of code into the console and run them
# 5. You should see a new file called 'outfile.csv' (or a different name from step 3) in your working directory.
source("Script_Functions.R")
makeInput_inat("sampleData_1.csv",outfile="outfile.csv")


# makeInput_gbif
# 1. Find the folder you downloaded from GBIF. From the folder, take the files called "occurrence.txt" and "multimedia.txt" and place them in the working directory
# 2. Change the names in the code below to match your "occurrence.txt" and "multimedia.txt" file names.
# 3. Change the output file name from 'outfile.csv' to something more informative.
# 4. Copy and paste the two lines of code into the console and run them
# 5. You should see a new file called 'outfile.csv' (or a different name from step 3) in your working directory.
source("Script_Functions.R")
makeInput_gbif("sampleData_2_occurrence.txt","sampleData_3_multimedia.txt","outfile.csv")
	
#########################################################
################ duplicateRemover #######################
#########################################################

# before you begin, make sure that both of your input files are in the working directory. These files should both be in 'standard format'. In other words, both should be files processed using one of the makeInput script.
# this will compare "sampleData_5_newerFile.csv" and "sampleData_4_olderFile.csv", find the duplicates and return a trimmed version of "sampleData_5_newerFile.csv" that has any duplicates with "sampleData_4_olderFile.csv" removed so that only records unique to 'newerFile.csv' remain. 

# 1. Change the names below to the names of your older file (the one with fewer occurrences) and newer file (the one with more occurrences)
# 2. Change "outfile.csv" to something more descriptive
# 3. Copy and paste the two lines of code into the console and run them
# 4. You should see a new file called 'outfile.csv' (or a different name from step 3) in your working directory.
source("Script_Functions.R")
duplicateRemover("sampleData_4_olderFile.csv",
	"sampleData_5_newerFile.csv",
	"outfile.csv")



#########################################################
################ downloadImages #######################
#########################################################

# before you begin, make sure your input file (a standard format file) is in the working directory.
# 1. change "sampleData_6_forDownload.csv" below to the name of your input file. [The sample file has only 4 image urls]
# 2. If on a pc, change type="mac" to type="pc"
# 3. The images will be downloaded to the working directory. Keep in mind that if there are 10,000 image urls in 'infile.csv', then you'll be downloading 10,000 images to your working directory

source("Script_Functions.R")
downloadImages("sampleData_6_forDownload.csv",type="mac")


#########################################################
################ addMetaData #######################
#########################################################

# used when images were downloaded and data were collected with local version of color selector.
# this takes the origninal standard format file and the color selection data and inserts the metadata (location, date) into the color selection file
# make sure to set working directory prior to starting
# 1. change the file name from "sampleData_7_colorSamples.csv" to your file. This is the file that was output from ColorSelectorLocal. The rows in this file correspond to clicks on images
# 2. change the file name from "sampleData_6_forDownload.csv" to your file. This is the file that you used to download your images from iNaturalist prior to color selection
# 3. Set a new output file name by changing 'outfile.csv' below
source("Script_Functions.R")
addMetadata("sampleData_7_colorSamples.csv",
	"sampleData_6_forDownload.csv",
	"outfile.csv")


##################################################
########## SummarizeColorSamples ####################
##################################################
# summarizes all the samples from each image and returns a file with mean, variance, etc. of color for each of the images in the input file. The input file is the output of colorSelectorNet, which has the color of each sample (i.e. click) for a number of images. There are two different versions: 
	# local: takes as input a file generated from ColorSelectorLocal
	# net: takes as input a file generated from ColorSelectorNet

# make sure to set working directory prior to starting
# 1. change the file name from "sampleData_7_colorSamples.csv" to your file. This is the file that was output from ColorSelectorLocal. The rows in this file correspond to clicks on images
# 2. change the file name from "sampleData_6_forDownload.csv" to your file. This is the file that you used to download your images from iNaturalist prior to color selection
# 3. Set a new output file name by changing 'outfile.csv' below

source("Script_Functions.R")

# input a file from ColorSelectorLocal
SummarizeColorSamples_local("sampleData_7_colorSamples.csv","outfile.csv")

## OR ##

# input a file from ColorSelectorNet
SummarizeColorSamples_net("sampleData_8_colorSamples.csv","outfile.csv")