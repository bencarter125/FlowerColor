#
# ColorExtractorLocal

# To run this app follow the steps below. Detailed instructions can be found in the manual.

# 1) take a folder of images to be processed and transfer them to the 'Images' folder that is in the same folder as this app.R file
# 2) Click the 'Run App' icon with the green triangle above this window.
# 3) when the new window opens, click on the 'Select Image Folder' dropdown menu to select your folder of images
# 4) the outfile will not have column names. Here are the column names: 
    # # imageName,imageNumber,timeStamp,clickX,clickY,R,G,B
# [imageNumber= the order of the image within  the folder (1st, 2nd, 3rd, etc)]
# [clickX & clickY= the xy  coordinates of the click on the original image

######## end of instructions ##############


library(shiny)
library(raster)
library(rgdal)

# load some functions
source("functions/extractColor.R")
source("functions/getNext.R")

# Define UI for application 
# User interface ----
ui <- fluidPage(
    titlePanel("Flower Color Selection"),
    
    sidebarLayout(
        sidebarPanel(
            helpText("To begin, select a folder of images from the menu below"),
            selectInput("imageFolder","Select Image Folder",
                        choices=list.files(paste(getwd(),"/Images",sep=""))),      # might  need a PC version
            helpText("To start from any image, enter an image number, then 'Refresh' then 'Next'. So to view image 11, enter 10, then 'Refresh' then 'Next'. "),
            numericInput("numSelect","Enter Starting Image Number",1),
            helpText("Click button below once after entering a new starting number"),
            actionButton("counterReset",
                         label="Refresh Starting Number"),
            helpText("Click below to view the next image"),
            actionButton("nextImage",label="Next Image"),
            textOutput("imageInfo")
        ),
        
        mainPanel(
            # first image (for sizing)
            plotOutput("mainPlot",
                       brush = brushOpts(id="plot2_brush",resetOnNew=TRUE)),
            # second image (for clicking)
            imageOutput("plot2",
                        click="image_click"),
            # image counter
            verbatimTextOutput("kcount"),
            # click counter
            verbatimTextOutput("clickCount"),
            # color dot plotter
            plotOutput("colorPoints")

            
            
            )
    )
)

# Define server logic required to draw a histogram
server <- function(input, output) {
    
    ########## set up progress tracking variables ############
    # jcounter keeps track of image advancement since the last image number was entered into the image number textbox
    # clickCounter tracks number of clicks on an image
    # kcounter keeps track of the absolute image number
    jcounter<-reactiveValues(j=0)
    clickCounter<-reactiveValues(k=0)
    kcounter<-reactiveValues(k=1)
    
    # when nextImage is clicked, advance jcounter by 1
    observeEvent(input$nextImage,{jcounter$j<-jcounter$j+1})
    # when counterReset [Refresh button] is clicked, return jcounter to zero
    observeEvent(input$counterReset,{jcounter$j<-0})
    # set kcounter equal to jcounter value plus value entered into numSelect (text input box)
    observeEvent(input$nextImage,{
        kcounter$k<-(jcounter$j +  input$numSelect)
        })
    
    # when you click on an image, advance clickCounter by 1
    observeEvent(input$image_click,{
        clickCounter$k<-clickCounter$k+1
        })
    # when image advances, return clickCounter to 0
    observeEvent(input$nextImage,{clickCounter$k<-0})
    
    ############### build text outputs helping user track progress #############
    # build (for printing) a text bit indicating the value of jcounter
    output$currentK<-renderText({
        paste("j= ",jcounter$j)
        })
    
    # build (for printing) counter indicating number of clicks on current image
    output$clickCount<-renderText({
        print(paste("Number of clicks on this image:",clickCounter$k))
        })
    # build (for printing) number of images left for the current species
    output$kcount<-renderText({
        nImgs<-length(allImages())  
        print(paste("This is image number",kcounter$k,"out of",
                    nImgs,"for this folder"))
        })
    
    ################### Define image list and current image #####################3
    # define the plotting image based on dropdown menu and kCounter
    # allImages is a list of all the images in the folder specified with the dropdown menu
    allImages<-reactive({
        list.files(paste(getwd(),"/Images/",input$imageFolder,sep=""))
        })
    # theImage is filename of the current image from allImages as defined by kCounter
    theImage<-reactive({
        paste(paste(getwd(),"/Images/",input$imageFolder,"/",allImages()[kcounter$k],sep=""))
        })
    # im is the loaded image to be plotted
    im<-reactive({brick(theImage())})
    
   
    ################## The main plot ############################3
    
    output$mainPlot <- renderPlot({
        # generate bins based on input$bins from ui.R
        if(kcounter$k==0) {
            plot(0,0,col=0)
            text(0,0,"Click Next Image to load image")
        } else {
            plotRGB(im(),r=1,g=2,b=3)
            }
    })
    
    # ------------------------- plot zooming stuff ---------------
    ranges2 <- reactiveValues(x = NULL, y = NULL)
    
    output$plot2 <- renderPlot({
        if(kcounter$k==0) {
            plot(0,0,col=0)
            text(0,0,"Click Next Image to load image")
        } else {
            plotRGB(im(),r=1,g=2,b=3,ext=c(ranges2$x,ranges2$y))
            }
    })
    
    observe({
        brush <- input$plot2_brush
        if (!is.null(brush)) {
            ranges2$x <- c(brush$xmin, brush$xmax)
            ranges2$y <- c(brush$ymin, brush$ymax)
            
        } else {
            ranges2$x <- NULL
            ranges2$y <- NULL
        }
    })
    # ------------------------ end plot zooming stuff ------------
    
    output$colorPoints<-renderPlot({
        plot(0,0,col=0)
        if(clickCounter$k!=0){
            ext<-extract(im(),data.frame(matrix(c(input$image_click$x,input$image_click$y),nrow=1)))
            points(0,0,pch=19,col=rgb(ext[1,1]/255,ext[1,2]/255,ext[1,3]/255,1),cex=5)
        }
    })
    
    output$clickInfo2<-renderPrint({
        if(length(input$image_click$x)!=1) {
            print("Click to get RGB values")
        } else {
        #im<-brick("image.jpg")
        ext<-extract(im(),data.frame(matrix(c(input$image_click$x,input$image_click$y),nrow=1)))
        colnames(ext)<-c("R","G","B")
        print(ext)
        }
    })
    
    
    output$imageInfo<-renderPrint({
        nImgs<-length(allImages())      
        print(paste("Number of images in this folder:",nImgs))
    })
    
   
    observeEvent(input$image_click,{
        
        timest<-as.character(Sys.time())
        
        ext<-extract(im(),data.frame(matrix(c(input$image_click$x,input$image_click$y),nrow=1)))
        ext<-as.vector(ext[1,])
        output<-c(theImage(),
                  kcounter$k,
                  timest,
                  input$image_click$x,
                  input$image_click$y,
                  ext)
        cat(paste(paste(output,collapse=","),"\n",sep=""),
            file="outfile.csv",append=TRUE)
        
    })
 
}



# Run the application 
shinyApp(ui = ui, server = server)
